#initialisation file
# =============================================================================
# from .combine_par       import combine_par
# from .model_appr        import model_appr
# from .random_init_model import random_init_model
# from .combine_and_fit   import combine_and_fit
# from .famos_directories import famos_directories
# from .get_results       import get_results
# from .get_model         import get_model
# from .base_optim        import base_optim
# =============================================================================
from .famos import *
